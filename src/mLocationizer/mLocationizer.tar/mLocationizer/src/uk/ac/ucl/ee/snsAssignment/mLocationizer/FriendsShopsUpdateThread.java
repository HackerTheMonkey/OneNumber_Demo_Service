package uk.ac.ucl.ee.snsAssignment.mLocationizer;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.List;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Paint;
import android.location.Location;
import android.location.LocationManager;
import android.os.Looper;
import android.widget.Toast;

import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;

public class FriendsShopsUpdateThread implements Runnable 
{

	private Context context =  null;
	private MapView mapView = null;
	private Location location = null;
	
	public FriendsShopsUpdateThread(Context context, MapView mapView, Location location)
	{
		this.context = context;
		this.mapView = mapView;
		this.location = location;
	}
	
	@Override
	public void run() 
	{
		Looper.prepare();
		/*
		 * Now we need to retrieve the list of shops and friends and display them, the shops to be displayed are within 300 meters from
		 * the location of the current user
		 */
		SharedPreferences serverIPAddressSttings = context.getSharedPreferences(ShowSettingsSubActivity.SERVERIPADDRESS, 0);
		SharedPreferences portNumberSettings = context.getSharedPreferences(ShowSettingsSubActivity.PORTNUMBER, 0);
		String hostname = serverIPAddressSttings.getString(ShowSettingsSubActivity.SERVERIPADDRESS, MainActivity.DEFAULT_SERVER_IP_ADDRESS);
		int port = portNumberSettings.getInt(ShowSettingsSubActivity.PORTNUMBER, MainActivity.DEFAULT_SERVER_PORT_NUMBER);
		try
		{
			InetAddress address = InetAddress.getByName(hostname);
			Socket connection = new Socket(address, port);
			Message message = new Message(Message.MSG_TYPE_GET_SHOPS_FRIENDS_REQUEST);
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(connection.getOutputStream());
			message.putParameterKeyValue(Message.PAR_TYPE_MSISDN, (new NetworkInformationRetriever(context)).getMsisdn());
			objectOutputStream.writeObject(message);
			objectOutputStream.flush();
			ObjectInputStream objectInputStream = new ObjectInputStream(connection.getInputStream());
			ArrayMessage responseMessage = (ArrayMessage)objectInputStream.readObject();				
			String locationArray[] = responseMessage.getParameterValue(ArrayMessage.PAR_TYPE_SHOPS_FRIENDS);
			String asd = "" + locationArray.length;			
			//String locationArray[] = {"Bloomsbury Theatre", "-0.133041", "51.525264", "Euston Station", "-0.135766", "51.525557"};
			for (int i = 0 ; i < locationArray.length ; i++)
			{
				String locationName = locationArray[i++];				
				String locationLongitude = locationArray[i++];
				String locationLatitude = locationArray[i];	
				if (locationLatitude.equals("asd")) continue;					
				Paint shopPaint = new Paint();
				shopPaint.setAntiAlias(true);									
				shopPaint.setARGB(180,130,117,100);
				MyPositionOverlay shopOverlay = new MyPositionOverlay(shopPaint, locationName);
				List<Overlay> myLocationOverlay1 = mapView.getOverlays();
				myLocationOverlay1.add(shopOverlay);
				Location shopLocation = new Location(LocationManager.GPS_PROVIDER);
				shopLocation.setLongitude(Double.parseDouble(locationLongitude));
				shopLocation.setLatitude(Double.parseDouble(locationLatitude));
				shopOverlay.setLocation(shopLocation);
				String x = Float.toString(location.distanceTo(shopLocation));
				Toast.makeText(context, x, Toast.LENGTH_LONG).show();
			}
			/*
			 * Close the connections
			 */
//			connection.close();
//			//objectInputStream.close();
//			objectOutputStream.close();
		}
		catch(Exception e)
		{
			Toast.makeText(context, e.getMessage(), Toast.LENGTH_LONG).show();
		}

	}

}
