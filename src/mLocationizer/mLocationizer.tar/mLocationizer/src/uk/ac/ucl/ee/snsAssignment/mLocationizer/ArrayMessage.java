package uk.ac.ucl.ee.snsAssignment.mLocationizer;

import java.io.Serializable;
import java.util.HashMap;

@SuppressWarnings("serial")
public class ArrayMessage implements Serializable 
{
	// Message Types
	public static final int MSG_TYPE_GET_SHOPS_FRIENDS_REQUEST = 20;
	public static final int MSG_TYPE_GET_SHOPS_FRIENDS_RESPONSE = 21;
	public static final String PAR_TYPE_SHOPS_FRIENDS = "PAR_TYPE_SHOPS_FRIENDS";
	private HashMap<String,String[]>  messageParameters = new HashMap<String, String[]>();
	private static final String PARM_NOT_EXIST = "The parameter does not exist";
	
	
	public void putParameterKeyValue(String key, String value[])
	{
		messageParameters.put(key, value);
	}
	 
	 public String[] getParameterValue(String parameterName)
	 {
		 String[] par = messageParameters.get(parameterName);		 
		 if (par.equals(null)) 
		 {
			 return null;
		 }
		 return par;
	 }
}